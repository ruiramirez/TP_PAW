import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-resale-form',
  templateUrl: './resale-form.component.html',
  styleUrls: ['./resale-form.component.css']
})
export class ResaleFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
